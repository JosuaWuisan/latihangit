import React from 'react'

const Logo = () => {
  return (
    <div>
        <h3>logo</h3>
    </div>
  )
}

export default Logo