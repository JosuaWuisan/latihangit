import React from 'react'

const Gen2 = () => {
  return (
    <div>
        <p>gen2</p>
    </div>
  )
}

export default Gen2