import React from 'react'

const Gen1 = () => {
  return (
    <div>
    <p>gen1</p>
    </div>
  )
}

export default Gen1