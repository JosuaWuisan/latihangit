import React from 'react'

const Gen4 = () => {
  return (
    <div>
        <p>gen4</p>
    </div>
  )
}

export default Gen4