import React from 'react'

const Gen3 = () => {
  return (
    <div>
        <p>gen3</p>
    </div>
  )
}

export default Gen3