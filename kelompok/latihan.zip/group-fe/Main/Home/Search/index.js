import React from 'react'

const Search = () => {
  return (
    <div>
        <h2>search</h2>
    </div>
  )
}

export default Search