import React from "react";
import CardInfo from "../Main/Home/Card-Info";
import Search from "../Main/Home/Search";

const Home = () => {
  return (
    <div>
      <h1>home</h1>
      <Search />
      <CardInfo />
    </div>
  );
};

export default Home;
