import React from 'react'

const TypeEffect = () => {
  return (
    <div>
        <p>typeEffect</p>
    </div>
  )
}

export default TypeEffect